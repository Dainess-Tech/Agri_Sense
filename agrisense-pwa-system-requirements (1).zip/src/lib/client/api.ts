"use client";
import { enqueue } from "./offline-queue";

/** Centralised API client for /api/v1 — all frontend data access goes through here. */
export class ApiClientError extends Error {
  constructor(public status: number, message: string, public details?: unknown, public code?: string) {
    super(message);
  }
}

export interface ApiOptions {
  method?: "GET" | "POST" | "PATCH" | "DELETE";
  body?: unknown;
  /** If the request fails because the device is offline, queue it in IndexedDB for later sync. */
  offlineQueue?: { label: string };
}

export type Queued = { queued: true };

export async function api<T = unknown>(path: string, opts: ApiOptions = {}): Promise<T> {
  const url = path.startsWith("/api/") ? path : `/api/v1${path}`;
  const method = opts.method ?? "GET";
  const queue = async () => {
    await enqueue({ method: method as "POST" | "PATCH" | "DELETE", url, body: opts.body, label: opts.offlineQueue!.label });
    return { queued: true } as T;
  };
  if (opts.offlineQueue && method !== "GET" && typeof navigator !== "undefined" && !navigator.onLine) return queue();
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: opts.body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      credentials: "same-origin",
    });
  } catch {
    if (opts.offlineQueue && method !== "GET") return queue();
    throw new ApiClientError(0, "You appear to be offline. Showing saved data where available.");
  }
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    if (res.status === 401 && typeof window !== "undefined" && !url.includes("/auth/")) {
      window.location.href = `/auth/login?next=${encodeURIComponent(window.location.pathname)}`;
    }
    const message = data?.error?.message ?? `Request failed (${res.status})`;
    throw new ApiClientError(res.status, message, data?.error?.details, data?.error?.code);
  }
  if (res.headers.get("x-agrisense-cache") === "offline" && data && typeof data === "object") {
    (data as Record<string, unknown>).__offline = true;
  }
  return data as T;
}

export function isQueued(v: unknown): v is Queued {
  return !!v && typeof v === "object" && (v as Queued).queued === true;
}

/** Formats validation issues from 422 responses into a readable string. */
export function errorMessage(e: unknown): string {
  if (e instanceof ApiClientError) {
    if (Array.isArray(e.details) && e.details.length) {
      return e.details.map((d: { path?: unknown[]; message?: string }) => `${(d.path ?? []).join(".")}: ${d.message}`).join("; ");
    }
    return e.message;
  }
  return e instanceof Error ? e.message : "Something went wrong";
}
