import "server-only";
import { db } from "@/db";
import { auditLogs, farmActivities } from "@/db/schema";

/** Audit trail for important administrative / security operations. */
export async function audit(actorId: string | null, action: string, entity: string, entityId?: string | null, meta?: unknown) {
  try {
    await db.insert(auditLogs).values({ actorId, action, entity, entityId: entityId ?? null, meta: meta ?? null });
  } catch (e) {
    console.error("[audit] failed", e);
  }
}

export async function logActivity(farmId: string, userId: string | null, type: string, description: string, plantingId?: string | null) {
  await db.insert(farmActivities).values({ farmId, userId, type, description, plantingId: plantingId ?? null });
}

/**
 * Transactional email abstraction. In "console" mode (no provider configured)
 * messages are logged and the link is returned to the client so the demo works.
 * Plug a provider (Resend, SES, SMTP) here via MAIL_PROVIDER + credentials.
 */
export function mailConsoleMode() {
  return !process.env.MAIL_PROVIDER;
}

export async function sendMail(to: string, subject: string, text: string) {
  if (mailConsoleMode()) {
    console.log(`[mail:console] to=${to} subject="${subject}"\n${text}`);
    return { delivered: false };
  }
  // TODO: integrate provider (e.g. Resend) using process.env.MAIL_API_KEY
  console.log(`[mail] provider ${process.env.MAIL_PROVIDER} not yet implemented; to=${to}`);
  return { delivered: false };
}

export function appUrl(req: Request) {
  return process.env.APP_URL || new URL(req.url).origin;
}
